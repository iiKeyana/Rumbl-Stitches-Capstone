export default function Home() {
    return (
        <div className="home">
            <h1>Welcome to Rumbl Stitches</h1>
            <p>Anime-inspired streetwear collections.</p>
        </div>
    );
}