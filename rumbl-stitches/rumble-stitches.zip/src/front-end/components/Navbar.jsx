import { Link } from "react-router-dom";
import "../assets/css/navbar.css";

export default function Navbar() {
    return (
        <nav className="navbar">
            <Link to="/" className="logo">
                RUMBL STITCHES
            </Link>

            <div className="nav-links">
                <Link to="/collections">Collections</Link>
                <Link to="/products">Shop</Link>
            </div>

            <div className="nav-right">
                <Link to="/cart">Cart</Link>
            </div>
        </nav>
    );
}